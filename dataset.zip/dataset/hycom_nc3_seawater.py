#!/usr/bin/env python3
"""
Reproduce the HYCOM seawater temperature / salinity / density statistics in
ABPmer R.4366 "Detailed Metocean Design Report NC3" (Section 3.2.2, Tables 6, 41-43)
and the spreadsheet R4366v3_NC3_N3p5_AirAndSeaProperties.xlsx ("Sea-water Statistics").

Report basis
  * Source   : HYCOM GOFS 3.1 (GLBv0.08), 3-hourly - the report text says GLBu0.08/expt_19.1,
               but that ends in 2012 and is daily-only after; the data match GLBv0.08 instead:
               - Table 6 point 54.04 N is a GLBv0.08 grid row (0.04 deg), not a GLBu0.08 one (0.08 deg)
               - the report starts 01/01/1994 12:00, exactly where GLBv0.08 expt_53.X starts
               - 53.X to 2015-12, 56.3 to 2016-09, 57.2 to 2016-12 gives exactly 66 223 time steps
               - the deepest wet level at 54.04/6.88 in GLBv0.08 is 30 m, as in the report
  * Point    : 54.04 N, 6.88 E (Table 6, NC 3 / N3.5)
  * Period   : 01/01/1994 12:00 - 31/12/2016 21:00 (23 years, 3 h, 66 223 values after gaps)
  * Layers   : surface 0 m, near bed 30 m (deepest bin); mid depth not stated - assumed 15 m

Corrected steps for other people:

   Open the point form, not the gridded one. The address ends in pointDataset.html:
   1994–2015: https://ncss.hycom.org/thredds/ncss/grid/GLBv0.08/expt_53.X/data/2000/pointDataset.html, changing 2000 to the year.
   Jan–Sep 2016: the same address with GLBv0.08/expt_56.3/pointDataset.html
   Oct–Dec 2016: the same address with GLBv0.08/expt_57.2/pointDataset.html
   
   The dataset.html address I gave earlier opens the gridded form, which has no latitude/longitude point fields.
   
   Tick water_temp and salinity.
   Enter Latitude 54.04, Longitude 6.88.
   Set Start and End, e.g. 2000-07-10T00:00:00Z and 2000-07-10T21:00:00Z.
   Set Level to 0, 15 or 30.
   Set Format to csv (or “csv (file)” to download it as a file), then click Submit.

Usage (on a machine that can open https://ncss.hycom.org):
  pip install numpy pandas openpyxl
  python3 hycom_nc3_seawater.py                 # download (resumable) + statistics
  python3 hycom_nc3_seawater.py --probe         # just check which datasets respond
  python3 hycom_nc3_seawater.py --stats-only    # recompute from what is downloaded
Options: --lat --lon --start --end --mid-depth --bed-depth --out --workers
"""
import argparse
import calendar
import csv
import io
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import threading
from datetime import datetime, timedelta, timezone

NCSS = "https://ncss.hycom.org/thredds/ncss/grid"

# (label, candidate NCSS paths; '{y}' = year).  First path that answers is used.
DATASETS = [
    ("expt_53.X", ["GLBv0.08/expt_53.X/data/{y}"]),     # reanalysis 1994-01-01 12Z .. 2015-12-31
    ("expt_56.3", ["GLBv0.08/expt_56.3"]),              # analysis 2014-07 .. 2016-09
    ("expt_57.2", ["GLBv0.08/expt_57.2"]),              # analysis 2016-05 .. 2017-02
]
# Each experiment is used only inside its window (one hands over to the next, gaps are not
# back-filled from the overlapping experiment) - this reproduces the report's 66 223 steps.
WINDOWS = {
    "expt_53.X": (datetime(1994, 1, 1, tzinfo=timezone.utc), datetime(2015, 12, 31, 23, 59, 59, tzinfo=timezone.utc)),
    "expt_56.3": (datetime(2016, 1, 1, tzinfo=timezone.utc), datetime(2016, 9, 30, 23, 59, 59, tzinfo=timezone.utc)),
    "expt_57.2": (datetime(2016, 10, 1, tzinfo=timezone.utc), datetime(2017, 12, 31, 23, 59, 59, tzinfo=timezone.utc)),
}

PCTS = [99, 95, 90, 75, 50, 25, 10, 5, 1]
MONTHS = list(calendar.month_name)[1:]

# Report values (Tables 41-43) for a quick check: mean, min, max, then PCTS
REPORT = {
    "Temperature": {
        "Surface":   [11.32, 0.33, 23.00, 19.86, 18.54, 17.85, 15.85, 11.16, 6.89, 5.25, 4.18, 2.67],
        "Mid Depth": [11.17, 0.35, 20.69, 19.29, 18.31, 17.65, 15.62, 10.97, 6.84, 5.22, 4.15, 2.66],
        "Near Bed":  [10.59, 0.66, 19.37, 18.51, 17.69, 16.97, 14.73, 10.05, 6.66, 5.15, 4.09, 2.21],
    },
    "Salinity": {
        "Surface":   [33.46, 29.17, 35.00, 34.72, 34.56, 34.46, 34.12, 33.47, 32.95, 32.47, 32.09, 31.04],
        "Mid Depth": [33.50, 30.28, 35.00, 34.72, 34.56, 34.46, 34.13, 33.49, 33.00, 32.54, 32.25, 31.57],
        "Near Bed":  [33.70, 31.33, 35.00, 34.74, 34.56, 34.46, 34.20, 33.71, 33.26, 32.90, 32.70, 32.31],
    },
    "Density": {
        "Surface":   [1025.3, 1020.6, 1027.4, 1027.1, 1027.0, 1026.8, 1026.5, 1025.4, 1024.3, 1023.6, 1023.2, 1022.2],
        "Mid Depth": [1025.4, 1021.8, 1027.4, 1027.2, 1027.0, 1026.9, 1026.5, 1025.5, 1024.4, 1023.7, 1023.4, 1022.8],
        "Near Bed":  [1025.7, 1023.1, 1027.5, 1027.3, 1027.1, 1027.0, 1026.7, 1025.9, 1024.8, 1024.2, 1023.9, 1023.4],
    },
}


# --------------------------------------------------------------------------- http
def _ssl_context():
    """Use certifi's CA bundle if available (python.org macOS builds often lack system certs)."""
    import ssl
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


SSL_CTX = _ssl_context()
LAST_ERROR = {}


def http_get(url, timeout=600, tries=4, pause=10):
    last = None
    for k in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "hycom-point-extract/1.0"})
            with urllib.request.urlopen(req, timeout=timeout, context=SSL_CTX) as r:
                return r.status, r.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", "replace") if hasattr(e, "read") else ""
            if e.code in (400, 404):          # bad request / no such dataset: don't retry
                return e.code, body
            last = f"HTTP {e.code}"
        except Exception as e:                 # timeouts, resets, SSL problems
            last = repr(e)
            if "CERTIFICATE_VERIFY_FAILED" in last:
                LAST_ERROR[url] = last
                return None, last              # retrying won't help
        LAST_ERROR[url] = last
        if k < tries - 1:
            time.sleep(pause * (k + 1))
    return None, last


def iso(dt):
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def parse_iso(s):
    s = s.strip().replace("Z", "")
    for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M", "%Y-%m-%d"):
        try:
            return datetime.strptime(s[:19], fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            pass
    raise ValueError(s)


_cov_cache = {}


def coverage(path):
    """Return (begin, end) of an NCSS grid dataset, or None if it doesn't respond."""
    if path in _cov_cache:
        return _cov_cache[path]
    code, txt = http_get(f"{NCSS}/{path}/dataset.xml", timeout=60, tries=2, pause=2)
    cov = None
    if code == 200 and txt:
        b = re.search(r"<begin>([^<]+)</begin>", txt)
        e = re.search(r"<end>([^<]+)</end>", txt)
        if b and e:
            cov = (parse_iso(b.group(1)), parse_iso(e.group(1)))
    if cov is None:
        LAST_ERROR[path] = f"HTTP {code}: {str(txt)[:150]}" if code else str(txt)[:200]
    _cov_cache[path] = cov
    return cov


def resolve(label, paths, year):
    for p in paths:
        p = p.format(y=year)
        cov = coverage(p)
        if cov:
            w0, w1 = WINDOWS.get(label, cov)
            cov = (max(cov[0], w0), min(cov[1], w1))
            return (p, cov) if cov[0] <= cov[1] else (None, None)
    return None, None


# --------------------------------------------------------------------------- download
def fetch_chunk(path, t0, t1, lat, lon):
    """NCSS point request, all 40 levels (slow; only used for the one-step depth check)."""
    q = [("var", "water_temp"), ("var", "salinity"),
         ("latitude", f"{lat}"), ("longitude", f"{lon}"),
         ("time_start", iso(t0)), ("time_end", iso(t1)), ("accept", "csv")]
    url = f"{NCSS}/{path}?" + urllib.parse.urlencode(q)
    return http_get(url)


# OPeNDAP on the same server: one request returns a strided set of depth levels for a
# whole month, ~2-3x faster than NCSS (which only does one level, or all 40, per request)
DODS = "https://tds.hycom.org/thredds/dodsC"
EPOCH = datetime(2000, 1, 1, tzinfo=timezone.utc)      # "hours since 2000-01-01" on all GLBu0.08
CSV_HDR = ('time,latitude[unit="degrees_north"],longitude[unit="degrees_east"],'
           'vertCoord[unit="m"],water_temp[unit="degC"],salinity[unit="psu"]')
_axes_cache = {}
_axes_lock = threading.Lock()


def dap_arrays(txt):
    """Parse an OPeNDAP .ascii reply into {name: flat list of floats}."""
    out, name = {}, None
    for line in txt.split("-" * 45, 1)[-1].splitlines():
        line = line.strip()
        if not line:
            name = None
        elif re.match(r"^[A-Za-z_][\w.]*(\[\d+\])+$", line):
            name = line.split("[")[0]
            out[name] = []
        elif name:
            line = re.sub(r"^(\[\d+\])+,", "", line)          # "[t][z][y], v" rows
            out[name] += [float(v) for v in line.split(",") if v.strip()]
    return out


def dap_axes(path):
    with _axes_lock:
        if path not in _axes_cache:
            code, txt = http_get(f"{DODS}/{path}.ascii?time,lat,lon,depth", timeout=300)
            if code != 200 or "time[" not in txt:
                raise RuntimeError(f"OPeNDAP axes for {path}: code={code} {str(txt)[:200]!r}")
            _axes_cache[path] = dap_arrays(txt)
        return _axes_cache[path]


def dap_fetch(path, t0, t1, lat, lon, levels):
    """Same CSV layout as NCSS (packed values) for the given depth levels, via OPeNDAP."""
    from math import gcd
    ax = dap_axes(path)
    h0, h1 = [(t - EPOCH).total_seconds() / 3600 for t in (t0, t1)]
    ti = [i for i, t in enumerate(ax["time"]) if h0 <= t <= h1]
    if not ti:
        return None, f"no time steps in {iso(t0)}..{iso(t1)}"
    yi = min(range(len(ax["lat"])), key=lambda i: abs(ax["lat"][i] - lat))
    xi = min(range(len(ax["lon"])), key=lambda i: abs((ax["lon"][i] + 180) % 360 - 180 - lon))
    zi = sorted({min(range(len(ax["depth"])), key=lambda i: abs(ax["depth"][i] - z)) for z in levels})
    step = 0
    for a, b in zip(zi, zi[1:]):
        step = gcd(step, b - a)
    step = max(step, 1)
    # one strided request if it adds no unwanted levels, else one request per level
    # (each extra level costs server time: ~18 s for 1 level/month vs ~80 s for 10)
    slabs = [f"{zi[0]}:{step}:{zi[-1]}"] if (zi[-1] - zi[0]) // step + 1 == len(zi) else [str(i) for i in zi]
    la, lo = ax["lat"][yi], (ax["lon"][xi] + 180) % 360 - 180
    out = {}
    for zs in slabs:
        hyper = f"[{ti[0]}:{ti[-1]}][{zs}][{yi}][{xi}]"
        q = urllib.parse.quote(f"water_temp{hyper},salinity{hyper}", safe=",:")
        code, txt = http_get(f"{DODS}/{path}.ascii?{q}")
        if code != 200 or "water_temp.water_temp" not in txt:
            return code, txt
        d = dap_arrays(txt)
        T, S = d["water_temp.water_temp"], d["salinity.salinity"]
        tt, zz = d["water_temp.time"], d["water_temp.depth"]
        for k, t in enumerate(tt):
            for j, z in enumerate(zz):
                n = k * len(zz) + j
                out[(t, z)] = (T[n], S[n])
    rows = [CSV_HDR] + [f"{iso(EPOCH + timedelta(hours=t))},{la:.4f},{lo:.4f},{z:g},{T:g},{S:g}"
                        for (t, z), (T, S) in sorted(out.items())]
    return 200, "\n".join(rows) + "\n"


# --------------------------------------------------------------------------- AWS direct reads
# expt_53.X through HYCOM's server costs ~1-2 s per (time step, level, variable): the server
# reads a whole global level for every value.  The same files are on AWS Open Data as
# uncompressed NetCDF-3 (one 4.8 GB file per 3-hour step), so each value can be read with a
# 2-byte HTTP range request instead.  Values are identical to the server's (checked 2026-10-15).
S3_HOST = "hycom-gofs-3pt1-reanalysis.s3.us-west-2.amazonaws.com"   # 1994 .. 2015 only
S3_LABEL = "expt_53.X"
_tl = threading.local()


def s3_get(key, start, n):
    """bytes, or None for a missing file (404); raises after repeated other failures."""
    import http.client
    for k in range(5):
        try:
            if not hasattr(_tl, "c"):
                _tl.c = http.client.HTTPSConnection(S3_HOST, timeout=60, context=SSL_CTX)
            _tl.c.request("GET", "/" + key, headers={"Range": f"bytes={start}-{start + n - 1}"})
            r = _tl.c.getresponse()
            b = r.read()
            if r.status in (200, 206):
                return b
            if r.status == 404:
                return None
        except Exception:
            _tl.__dict__.pop("c", None)
        time.sleep(2 * (k + 1))
    raise RuntimeError(f"S3 read failed: {key}")


def s3_keys(year):
    """{valid time: key} for one year folder (keys look like .../hycom_GLBv0.08_530_1994010112_t003.nc)."""
    out, token = {}, None
    while True:
        q = {"list-type": "2", "prefix": f"{year}/"}
        if token:
            q["continuation-token"] = token
        code, txt = http_get(f"https://{S3_HOST}/?" + urllib.parse.urlencode(q), timeout=120)
        if code != 200:
            raise RuntimeError(f"S3 listing {year}: code={code}")
        for key, size in re.findall(r"<Key>([^<]+\.nc)</Key>.*?<Size>(\d+)</Size>", txt):
            m = re.search(r"_(\d{10})_t(\d{3})\.nc$", key)
            if m:
                t = datetime.strptime(m.group(1), "%Y%m%d%H").replace(tzinfo=timezone.utc) + timedelta(hours=int(m.group(2)))
                out.setdefault(t, (key, int(size)))
        m = re.search(r"<NextContinuationToken>([^<]+)<", txt)
        if not m:
            return out
        token = m.group(1)


_layouts = {}


def s3_layout(key, size):
    """Byte offsets of water_temp/salinity and the grid, from the file header (cached per file size)."""
    import struct
    if size in _layouts:
        return _layouts[size]
    buf = s3_get(key, 0, 65536)
    p = [4]
    u32 = lambda: (struct.unpack_from(">I", buf, p[0])[0], p.__setitem__(0, p[0] + 4))[0]
    u64 = lambda: (struct.unpack_from(">Q", buf, p[0])[0], p.__setitem__(0, p[0] + 8))[0]

    def name():
        n = u32(); v = buf[p[0]:p[0] + n].decode(); p[0] += (n + 3) // 4 * 4; return v

    def skip_atts():
        u32()
        for _ in range(u32()):
            name(); t = u32(); c = u32()
            p[0] += ({1: 1, 2: 1, 3: 2, 4: 4, 5: 4, 6: 8}[t] * c + 3) // 4 * 4
    big = buf[3] == 2                       # 64-bit offset format
    u32()                                   # numrecs
    u32(); dims = [(name(), u32()) for _ in range(u32())]
    skip_atts()
    u32(); var = {}
    for _ in range(u32()):
        nm = name(); ids = [u32() for _ in range(u32())]; skip_atts(); u32(); u32()
        var[nm] = ([dims[i] for i in ids], u64() if big else u32())
    nlat, nlon = dict(dims)["lat"], dict(dims)["lon"]
    lat = struct.unpack(f">{nlat}d", s3_get(key, var["lat"][1], 8 * nlat))
    lon = struct.unpack(f">{nlon}d", s3_get(key, var["lon"][1], 8 * nlon))
    dep = struct.unpack(f">{dict(dims)['depth']}d", s3_get(key, var["depth"][1], 8 * dict(dims)["depth"]))
    _layouts[size] = dict(lat=lat, lon=lon, depth=dep, nlat=nlat, nlon=nlon,
                          T=var["water_temp"][1], S=var["salinity"][1])
    return _layouts[size]


def s3_download(args, levels, months, raw_dir, log):
    """Fetch every expt_53.X month (1994-2015) by byte-range reads; writes the same CSV as dap_fetch."""
    from concurrent.futures import ThreadPoolExecutor
    w0, w1 = WINDOWS[S3_LABEL]
    todo = [(y, m) for y, m in months if y <= 2015
            and not os.path.exists(os.path.join(raw_dir, f"{y}{m:02d}_{S3_LABEL}.csv"))]
    if not todo:
        return
    print(f"Reading {len(todo)} months of {S3_LABEL} directly from AWS ({args.s3_threads} connections) ...", flush=True)
    t_start = time.time()
    with ThreadPoolExecutor(args.s3_threads) as ex:
        for y in sorted({y for y, _ in todo}):
            # 1 Jan 00-09Z of year y sit in the previous year's folder (..._{y-1}123112_t012.nc etc.)
            keys = {t: v for yy in (y - 1, y) if yy >= 1994 for t, v in s3_keys(yy).items()
                    if w0 <= t <= w1 and t.year == y}
            for yy, m in [(a, b) for a, b in todo if a == y]:
                ms, me = month_bounds(yy, m)
                steps = sorted((t, k, sz) for t, (k, sz) in keys.items() if ms <= t <= me)
                if not steps:
                    continue
                lay = s3_layout(steps[0][1], steps[0][2])
                for _, k, sz in steps:
                    if sz != steps[0][2]:
                        s3_layout(k, sz)
                tic = time.time()
                jobs = []
                for t, k, sz in steps:
                    L = _layouts[sz]
                    j = min(range(L["nlat"]), key=lambda q: abs(L["lat"][q] - args.lat))
                    i = min(range(L["nlon"]), key=lambda q: abs((L["lon"][q] + 180) % 360 - 180 - args.lon))
                    for z in levels:
                        kz = min(range(len(L["depth"])), key=lambda q: abs(L["depth"][q] - z))
                        cell = 2 * ((kz * L["nlat"] + j) * L["nlon"] + i)
                        jobs.append((t, L["depth"][kz], k, L["T"] + cell, L["S"] + cell, L["lat"][j], L["lon"][i]))
                try:
                    vals = list(ex.map(lambda a: (s3_get(a[2], a[3], 2), s3_get(a[2], a[4], 2)), jobs))
                except RuntimeError as e:
                    msg = f"FAIL {yy}-{m:02d} {S3_LABEL:10s} AWS {e}"
                    print(msg, flush=True); log.write(msg + "\n"); log.flush()
                    continue
                rows = [CSV_HDR]
                for (t, z, _, _, _, la, lo), (bt, bs) in zip(jobs, vals):
                    if bt is not None and bs is not None:      # None = file missing on AWS (gap)
                        T, S = int.from_bytes(bt, "big", signed=True), int.from_bytes(bs, "big", signed=True)
                        rows.append(f"{iso(t)},{la:.4f},{(lo + 180) % 360 - 180:.4f},{z:g},{T},{S}")
                fn = os.path.join(raw_dir, f"{yy}{m:02d}_{S3_LABEL}.csv")
                with open(fn + ".part", "w") as f:
                    f.write("\n".join(rows) + "\n")
                os.replace(fn + ".part", fn)
                msg = (f"OK   {yy}-{m:02d} {S3_LABEL:10s} AWS {len(steps)} steps x {len(levels)} levels "
                       f"({len(rows) - 1} rows, {time.time() - tic:.0f}s)")
                print(msg, flush=True); log.write(msg + "\n"); log.flush()
    print(f"AWS part finished in {(time.time() - t_start) / 60:.0f} min.\n", flush=True)


def s3_wet_levels(args):
    """Depth levels with data at the point, from one AWS file (40 two-byte reads, a few seconds)."""
    from concurrent.futures import ThreadPoolExecutor
    keys = s3_keys(args.start)
    t = min(t for t in keys if t >= WINDOWS[S3_LABEL][0])
    key, size = keys[t]
    L = s3_layout(key, size)
    j = min(range(L["nlat"]), key=lambda q: abs(L["lat"][q] - args.lat))
    i = min(range(L["nlon"]), key=lambda q: abs((L["lon"][q] + 180) % 360 - 180 - args.lon))
    offs = [L["T"] + 2 * ((kz * L["nlat"] + j) * L["nlon"] + i) for kz in range(len(L["depth"]))]
    with ThreadPoolExecutor(20) as ex:
        raw = list(ex.map(lambda o: s3_get(key, o, 2), offs))
    return [z for z, b in zip(L["depth"], raw) if b and int.from_bytes(b, "big", signed=True) > -29999]


def wet_levels(args):
    """Depth levels with data at the point (one time step, all levels; ~1 request)."""
    if args.start <= 2015 and not args.no_s3:
        try:
            return s3_wet_levels(args)
        except Exception as e:
            print(f"  (AWS depth check failed: {e!r}; asking HYCOM's server, this can take minutes)", flush=True)
    for label, paths in DATASETS:
        path, cov = resolve(label, paths, args.start)
        if not cov:
            continue
        t = max(cov[0], datetime(args.start, 1, 1, tzinfo=timezone.utc))
        code, txt = fetch_chunk(path, t, t, args.lat, args.lon)
        if code != 200 or not txt:
            continue
        rows = list(csv.reader(io.StringIO(txt)))
        hdr = [c.split("[")[0].strip() for c in rows[0]]
        zi, ti = hdr.index("vertCoord"), hdr.index("water_temp")
        z = sorted({float(r[zi]) for r in rows[1:] if r and float(r[ti]) > -29999})
        if z:
            return z
    return None


def month_bounds(y, m):
    last = calendar.monthrange(y, m)[1]
    return (datetime(y, m, 1, tzinfo=timezone.utc),
            datetime(y, m, last, 23, 59, 59, tzinfo=timezone.utc))


def csv_span(fn):
    """(first, last) time in a downloaded chunk."""
    times = []
    with open(fn) as f:
        rd = csv.reader(f)
        hdr = next(rd)
        ti = next(i for i, c in enumerate(hdr) if c.split("[")[0].strip() == "time")
        for row in rd:
            if row:
                times.append(row[ti])
    if not times:
        return None
    return parse_iso(min(times)), parse_iso(max(times))


def largest_gap(ms, me, got, step_h=3):
    """Largest part of [ms, me] not covered by intervals in `got` (None if covered)."""
    from datetime import timedelta
    iv = sorted(g for g in got if g)
    gaps, cur = [], ms
    for a, b in iv:
        if a - cur > timedelta(hours=step_h):
            gaps.append((cur, a - timedelta(seconds=1)))
        cur = max(cur, b + timedelta(seconds=1))
    if me - cur > timedelta(hours=step_h):
        gaps.append((cur, me))
    if not gaps:
        return None
    return max(gaps, key=lambda g: g[1] - g[0])


def download(args):
    """Download month by month; months run in parallel (--workers, default 4)."""
    from concurrent.futures import ThreadPoolExecutor, as_completed
    raw_dir = os.path.join(args.out, "raw")
    os.makedirs(raw_dir, exist_ok=True)
    log = open(os.path.join(args.out, "download_log.txt"), "a")
    lock = threading.Lock()
    months = [(y, m) for y in range(args.start, args.end + 1) for m in range(1, 13)]
    t_start, done = time.time(), 0

    print(f"HYCOM point extraction at {args.lat} N, {args.lon} E, {args.start}-{args.end}", flush=True)
    print(f"Output folder: {os.path.abspath(args.out)}")
    print("Checking HYCOM datasets ...", flush=True)
    for label, paths in DATASETS:
        # per-year datasets: only check the first year that answers (some years' dataset.xml
        # hang on HYCOM's server; 1994-2015 is read from AWS anyway)
        covs = []
        for y in range(args.start, args.end + 1):
            c = resolve(label, paths, y)[1]
            if c or "{y}" not in paths[0]:
                covs.append(c)
                break
        covs = [c for c in covs if c]
        if covs:
            cov = (min(c[0] for c in covs), max(c[1] for c in covs))
            print(f"  {label:10s} {iso(cov[0])} .. {iso(cov[1])}", flush=True)
        else:
            err = LAST_ERROR.get(paths[0].format(y=args.start), "")
            print(f"  {label:10s} not available  -> {err}", flush=True)
            if "CERTIFICATE_VERIFY_FAILED" in err:
                sys.exit("\nPython cannot verify HTTPS certificates. Fix (macOS, python.org Python):\n"
                         '  open "/Applications/Python 3.11/Install Certificates.command"\n'
                         "or:  pip3 install certifi\nthen run this script again.")
    if not any(_cov_cache.values()):
        sys.exit("\nNo HYCOM dataset could be reached from Python - see the error above.\n"
                 "Check that https://ncss.hycom.org opens in your browser, and if the error mentions\n"
                 "certificates run:  pip3 install certifi")
    print("Finding depth levels with data at this point ...", flush=True)
    wet = wet_levels(args)
    if not wet:
        sys.exit("Could not determine the depth levels - check the errors above and retry.")
    if args.all_depths:
        levels = wet
    else:
        bed = args.bed_depth if args.bed_depth is not None else wet[-1]
        mid = args.mid_depth if args.mid_depth is not None else min(wet, key=lambda z: abs(z - bed / 2))
        levels = sorted({wet[0], mid, bed})
    print(f"  wet levels: {wet}\n  downloading: {levels} m"
          + ("" if args.all_depths else "   (use --all-depths for every wet level)"), flush=True)
    if not args.no_s3:
        s3_download(args, levels, months, raw_dir, log)

    n_have = len([f for f in os.listdir(raw_dir) if f.endswith(".csv")])
    if n_have:
        print(f"{n_have} chunk files already downloaded - those months are skipped.")
    print(f"Starting download with {args.workers} parallel requests. "
          "Each month takes ~1 min; a status line prints every minute.\n", flush=True)

    active = {}          # month -> start time, for the heartbeat
    stop = threading.Event()

    def heartbeat():
        while not stop.wait(60):
            with lock:
                el = (time.time() - t_start) / 60
                run = ", ".join(f"{k} ({(time.time()-v)/60:.0f} min)" for k, v in sorted(active.items()))
                print(f"[{time.strftime('%H:%M')}] {done}/{len(months)} months done, {el:.0f} min elapsed"
                      + (f"; downloading: {run}" if run else ""), flush=True)

    def do_month(y, m):
        ms, me = month_bounds(y, m)
        got, msgs = [], []
        for label, paths in DATASETS:
            fn = os.path.join(raw_dir, f"{y}{m:02d}_{label}.csv")
            if os.path.exists(fn):
                got.append(csv_span(fn))
                continue
            gap = largest_gap(ms, me, got)
            if gap is None:
                break                      # month complete
            path, cov = resolve(label, paths, y)
            if not cov or cov[1] < gap[0] or cov[0] > gap[1]:
                continue
            t0, t1 = max(gap[0], cov[0]), min(gap[1], cov[1])
            tic = time.time()
            key = f"{y}-{m:02d}"
            with lock:
                active[key] = tic
                print(f"     {key} {label:10s} requesting ...", flush=True)
            try:
                for _ in range(3):      # the server sometimes returns a header with no time/rows
                    code, txt = dap_fetch(path, t0, t1, args.lat, args.lon, levels)
                    ok = code == 200 and txt and txt.startswith("time,") and len(txt.splitlines()) > 1
                    if ok:
                        break
                    time.sleep(10)
            finally:
                with lock:
                    active.pop(key, None)
            if ok:
                with open(fn + ".part", "w") as f:
                    f.write(txt)
                os.replace(fn + ".part", fn)   # only complete files count as done
                got.append(csv_span(fn))
                msg = f"OK   {key} {label:10s} {iso(t0)} -> {iso(t1)}  ({len(txt.splitlines())-1} rows, {time.time()-tic:.0f}s)"
            else:
                msg = f"FAIL {key} {label:10s} {path} code={code} {str(txt)[:200]!r}"
            msgs.append(msg)
            with lock:
                print(msg, flush=True)
                log.write(msg + "\n")
                log.flush()
        return msgs

    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        threading.Thread(target=heartbeat, daemon=True).start()
        futs = [ex.submit(do_month, y, m) for y, m in months]
        for f in as_completed(futs):
            done += 1
            try:
                f.result()
            except Exception as e:
                with lock:
                    print("ERROR", repr(e), flush=True)
            if done % 12 == 0:
                el = time.time() - t_start
                with lock:
                    print(f"--- {done}/{len(months)} months processed, {el/60:.0f} min elapsed, "
                          f"~{el/done*(len(months)-done)/60:.0f} min left", flush=True)
    stop.set()
    log.close()
    print(f"\nDownload finished in {(time.time()-t_start)/60:.0f} min.", flush=True)
    fails = sum(1 for l in open(os.path.join(args.out, "download_log.txt")) if l.startswith("FAIL"))
    if fails:
        print(f"\nSome requests failed - just run the same command again to retry only the missing months.")



def probe(args):
    print("Probing NCSS datasets (dataset.xml) ...")
    for label, paths in DATASETS:
        for p in paths:
            ys = sorted({args.start, 1995, 2005, args.end}) if "{y}" in p else [None]
            for y in ys:
                pp = p.format(y=y) if y else p
                cov = coverage(pp)
                print(f"  {label:10s} {pp:34s} ->", f"{iso(cov[0])} .. {iso(cov[1])}" if cov else "no response")


# --------------------------------------------------------------------------- parsing
def load_raw(args):
    import pandas as pd
    raw_dir = os.path.join(args.out, "raw")
    prio = {lab: i for i, (lab, _) in enumerate(DATASETS)}
    frames = []
    for fn in sorted(os.listdir(raw_dir)):
        if not fn.endswith(".csv"):
            continue
        label = re.sub(r"_z[\d.]+$", "", fn[:-4].split("_", 1)[1])   # 199401_expt_19.0_z25.csv
        df = pd.read_csv(os.path.join(raw_dir, fn))
        cols = {c: c.split("[")[0].strip() for c in df.columns}
        df = df.rename(columns=cols)
        zc = next((c for c in df.columns if c in ("vertCoord", "depth", "z")), None)
        df = df.rename(columns={zc: "depth"})
        df["time"] = pd.to_datetime(df["time"], utc=True)
        for c in ("water_temp", "salinity"):
            # NCSS CSV returns PACKED values: real = raw * 0.001 + 20 ; -30000 = no data (below seabed).
            # Decide per file: raw values near 0 (i.e. ~20 degC) are packed too.
            df.loc[df[c] <= -29999, c] = float("nan")
            if (df[c].abs() > 100).any():
                df[c] = df[c] * 0.001 + 20.0
        df["src"] = label
        df["prio"] = prio.get(label, 99)
        frames.append(df[["time", "depth", "water_temp", "salinity", "src", "prio", "latitude", "longitude"]])
    if not frames:
        sys.exit("No downloaded data found in " + raw_dir)
    d = pd.concat(frames, ignore_index=True)
    # where datasets overlap keep the higher-priority one (reanalysis first)
    d = d.sort_values(["time", "depth", "prio"]).drop_duplicates(["time", "depth"], keep="first")
    # QC: a few HYCOM time steps are corrupt (2000-05-10 12Z: salinity raw 0 = 20.000 at all depths;
    # 1996-09-07 15Z: salinity ~7 near the surface). Drop values outside a plausible range.
    bad = (d["salinity"] < 25) | (d["salinity"] > 40) | (d["water_temp"] < -2.5) | (d["water_temp"] > 35)
    if bad.any():
        # a corrupt time step is dropped at every depth (2008-02-22 03Z: bad S at 0/30 m, T=21.5 at 15 m)
        bad_t = set(d.loc[bad, "time"])
        print(f"QC: dropped {len(bad_t)} corrupt time steps:", sorted(t.strftime('%Y-%m-%d %H:%M') for t in bad_t))
        d = d[~d["time"].isin(bad_t)]
    return d


# --------------------------------------------------------------------------- density
def rho_unesco(S, T, p_dbar=0.0):
    """UNESCO EOS-80 density (kg/m3). With p=0 this is surface (potential-type) density."""
    import numpy as np
    S, T = np.asarray(S, float), np.asarray(T, float)
    rw = (999.842594 + 6.793952e-2 * T - 9.095290e-3 * T**2 + 1.001685e-4 * T**3
          - 1.120083e-6 * T**4 + 6.536332e-9 * T**5)
    r0 = (rw + S * (0.824493 - 4.0899e-3 * T + 7.6438e-5 * T**2 - 8.2467e-7 * T**3 + 5.3875e-9 * T**4)
          + S**1.5 * (-5.72466e-3 + 1.0227e-4 * T - 1.6546e-6 * T**2) + 4.8314e-4 * S**2)
    if not np.any(p_dbar):
        return r0
    P = np.asarray(p_dbar, float) / 10.0  # bar
    kw = 19652.21 + 148.4206 * T - 2.327105 * T**2 + 1.360477e-2 * T**3 - 5.155288e-5 * T**4
    aw = 3.239908 + 1.43713e-3 * T + 1.16092e-4 * T**2 - 5.77905e-7 * T**3
    bw = 8.50935e-5 - 6.12293e-6 * T + 5.2787e-8 * T**2
    k0 = kw + S * (54.6746 - 0.603459 * T + 1.09987e-2 * T**2 - 6.1670e-5 * T**3) \
        + S**1.5 * (7.944e-2 + 1.6483e-2 * T - 5.3009e-4 * T**2)
    a = aw + S * (2.2838e-3 - 1.0981e-5 * T - 1.6078e-6 * T**2) + 1.91075e-4 * S**1.5
    b = bw + S * (-9.9348e-7 + 2.0816e-8 * T + 9.1697e-10 * T**2)
    K = k0 + a * P + b * P**2
    return r0 / (1 - P / K)


# --------------------------------------------------------------------------- statistics
def stats_row(x):
    import numpy as np
    x = np.asarray(x, float)
    x = x[~np.isnan(x)]
    if x.size == 0:
        return [float("nan")] * (3 + len(PCTS))
    # 'hazen' = MATLAB prctile convention (the report was produced in MATLAB)
    return [x.mean(), x.min(), x.max()] + [float(np.percentile(x, p, method="hazen")) for p in PCTS]


def stats_table(series):
    import pandas as pd
    rows = {}
    for m in range(1, 13):
        rows[MONTHS[m - 1]] = stats_row(series[series.index.month == m].values)
    rows["All-Year"] = stats_row(series.values)
    cols = ["Mean", "Min", "Max"] + [f"P{p}" for p in PCTS]
    return pd.DataFrame.from_dict(rows, orient="index", columns=cols)


def compute(args):
    import numpy as np
    import pandas as pd
    d = load_raw(args)
    depths = sorted(d["depth"].dropna().unique())
    print(f"\nDepth bins returned at this point: {depths}")
    print(f"Grid point used by HYCOM: lat {d['latitude'].iloc[0]}, lon {d['longitude'].iloc[0]}")

    valid = d.dropna(subset=["water_temp"])
    bed = args.bed_depth if args.bed_depth is not None else max(valid["depth"].unique())
    mid = args.mid_depth if args.mid_depth is not None else min(depths, key=lambda z: abs(z - bed / 2))
    layers = {"Surface": min(depths), "Mid Depth": mid, "Near Bed": bed}
    print("Layers:", {k: f"{v} m" for k, v in layers.items()})

    t0 = pd.Timestamp(f"{args.start}-01-01", tz="UTC")
    t1 = pd.Timestamp(f"{args.end}-12-31 23:59", tz="UTC")
    d = d[(d["time"] >= t0) & (d["time"] <= t1)]

    # combined, unpacked, de-duplicated time series at every depth with data (one tidy CSV)
    allz = d.dropna(subset=["water_temp"]).copy()
    allz["density_kgm3"] = rho_unesco(allz["salinity"].values, allz["water_temp"].values)
    allz["time"] = allz["time"].dt.strftime("%Y-%m-%d %H:%M")
    ts_csv = os.path.join(args.out, "NC3_HYCOM_timeseries_all_depths.csv")
    allz[["time", "depth", "water_temp", "salinity", "density_kgm3", "src"]].rename(
        columns={"depth": "depth_m", "water_temp": "water_temp_degC", "salinity": "salinity_psu",
                 "src": "source"}).round(4).to_csv(ts_csv, index=False)
    print(f"Wrote {ts_csv}  ({len(allz)} rows)")

    out = {}
    series_out = {}
    for lname, z in layers.items():
        sub = d[d["depth"] == z].set_index("time").sort_index()
        T, S = sub["water_temp"], sub["salinity"]
        R = pd.Series(rho_unesco(S.values, T.values), index=sub.index)
        n = int(T.notna().sum())
        span = f"{sub.index.min()} .. {sub.index.max()}"
        print(f"  {lname:9s} ({z} m): {n} valid 3-h values, {span}; by source:",
              sub["src"].value_counts().to_dict())
        out[lname] = {"Temperature": stats_table(T), "Salinity": stats_table(S), "Density": stats_table(R)}
        series_out[lname] = pd.DataFrame({"water_temp_degC": T, "salinity_psu": S,
                                          "density_kgm3": R, "source": sub["src"]})

    # --- comparison with the report (All-Year rows)
    print("\nAll-year comparison  (yours  vs  report)")
    cols = ["Mean", "Min", "Max"] + [f"P{p}" for p in PCTS]
    for par in ("Temperature", "Salinity", "Density"):
        print(f"\n{par}")
        print(f"{'':10s}" + "".join(f"{c:>9s}" for c in cols))
        for lname in layers:
            mine = out[lname][par].loc["All-Year"].values
            rep = REPORT[par][lname]
            print(f"{lname:10s}" + "".join(f"{v:9.2f}" for v in mine))
            print(f"{'  report':10s}" + "".join(f"{v:9.2f}" for v in rep))

    # --- write Excel
    xl = os.path.join(args.out, "NC3_HYCOM_seawater_statistics.xlsx")
    with pd.ExcelWriter(xl) as w:
        info = pd.DataFrame({
            "item": ["Requested point", "HYCOM grid point", "Period", "Layers (m)", "Sources",
                     "Percentiles", "Density", "Report"],
            "value": [f"{args.lat} N, {args.lon} E",
                      f"{d['latitude'].iloc[0]} N, {d['longitude'].iloc[0]} E",
                      f"{args.start}-01-01 .. {args.end}-12-31, 3-hourly",
                      ", ".join(f"{k}={v}" for k, v in layers.items()),
                      "GLBv0.08 (GOFS 3.1) expt_53.X to 2015, expt_56.3 Jan-Sep 2016, expt_57.2 Oct-Dec 2016",
                      "numpy 'hazen' (= MATLAB prctile)",
                      "UNESCO EOS-80 at atmospheric pressure from T and S",
                      "ABPmer R.4366 Tables 41-43"],
        })
        info.to_excel(w, sheet_name="Info", index=False)
        for par in ("Temperature", "Salinity", "Density"):
            r = 0
            sheet = par[:31]
            for lname in layers:
                pd.DataFrame({f"{lname} ({layers[lname]} m) - {par}": []}).to_excel(w, sheet_name=sheet, startrow=r, index=False)
                out[lname][par].round(3).to_excel(w, sheet_name=sheet, startrow=r + 1)
                r += 17
        for lname, s in series_out.items():
            s2 = s.copy()
            s2.index = s2.index.tz_convert(None)
            s2.to_excel(w, sheet_name=f"TS {lname}"[:31])
    print(f"\nWrote {xl}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--lat", type=float, default=54.04)
    ap.add_argument("--lon", type=float, default=6.88)
    ap.add_argument("--start", type=int, default=1994)
    ap.add_argument("--end", type=int, default=2016)
    ap.add_argument("--mid-depth", type=float, default=None, help="default: bin nearest half the deepest bin (15 m; the report does not state it)")
    ap.add_argument("--bed-depth", type=float, default=None, help="default: deepest bin with data (30 m)")
    ap.add_argument("--out", default="hycom_nc3_gofs31")
    ap.add_argument("--workers", type=int, default=4, help="parallel downloads (be kind to HYCOM: 4-6)")
    ap.add_argument("--all-depths", action="store_true",
                    help="download every wet level, not just surface/mid/bed (~3x slower)")
    ap.add_argument("--s3-threads", type=int, default=64, help="parallel AWS range reads for 1994-2015")
    ap.add_argument("--no-s3", action="store_true", help="use HYCOM's server for every year (very slow for 1994-2015)")
    ap.add_argument("--probe", action="store_true")
    ap.add_argument("--stats-only", action="store_true")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    if a.probe:
        probe(a)
        return
    if not a.stats_only:
        download(a)
    compute(a)


if __name__ == "__main__":
    main()
